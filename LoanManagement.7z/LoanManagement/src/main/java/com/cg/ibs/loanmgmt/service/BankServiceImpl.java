package com.cg.ibs.loanmgmt.service;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDaoImpl;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDaoImpl;
import com.cg.ibs.loanmgmt.dao.LoanTypeDao;
import com.cg.ibs.loanmgmt.dao.LoanTypeDaoImpl;

public class BankServiceImpl implements BankService {
	private LoanMasterDao loanMasterDao = new LoanMasterDaoImpl();
	private CustomerDao customerDao = new CustomerDaoImpl();
	private LoanTypeDao loanTypeDao = new LoanTypeDaoImpl();
	private static EntityManager entityManager;
	private static EntityTransaction transaction = entityManager.getTransaction();
	private LoanMaster loanMaster = new LoanMaster();

	public List<LoanMaster> getPendingLoans() {
		List<LoanMaster> listTemp = null;
		listTemp = loanMasterDao.getPendingLoans();
		return listTemp;
	}

	public CustomerBean getCustomerDetailsByUci(BigInteger uci) {
		return customerDao.getCustomerDetailsByUci(uci);
	}

	public LoanTypeBean getLoanTypeByTypeID(Integer typeId) {
		return loanTypeDao.getLoanTypeByTypeID(typeId);
	}

	public BigInteger generateLoanNumber(LoanMaster loanMaster) {
		StringBuilder sb = new StringBuilder();
		sb.append(loanMaster.getAppliedDate().getYear()).append(loanMaster.getAppliedDate().getMonthValue())
				.append(loanMaster.getApplicationNumber());
		System.out.println(sb);
		BigInteger bigInteger = new BigInteger(sb.toString());
		return bigInteger;

	}

	public LoanMaster updateLoanApproval(LoanMaster loanMasterTemp) {
		transaction.begin();
		loanMaster = loanMasterDao.updateLoanApprovalDao(loanMasterTemp, generateLoanNumber(loanMasterTemp));
		transaction.commit();
		return loanMaster;
	}

	public void updateLoanDenial(LoanMaster loanMasterTemp) {
		transaction.begin();
		loanMasterDao.updateLoanDenialDao(loanMasterTemp);
		transaction.commit();
	
	}

}
