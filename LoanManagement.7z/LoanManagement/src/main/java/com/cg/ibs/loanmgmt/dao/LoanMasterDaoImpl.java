package com.cg.ibs.loanmgmt.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanStatus;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class LoanMasterDaoImpl implements LoanMasterDao {
	private static EntityManager entityManager;
	private LoanMaster loanMaster = null;
	private static Logger LOGGER = Logger.getLogger(LoanMasterDaoImpl.class);

	public LoanMasterDaoImpl() {
		LOGGER.info("Entity manager is being called");
		entityManager = JpaUtil.getEntityManger();
	}

	public LoanMaster getLoanByLoanNumber(BigInteger loanAccNum) {
		LOGGER.info("Loan number is input to obtain complete loan details.");
		TypedQuery<LoanMaster> query = entityManager.createQuery("Select l from Loan l", LoanMaster.class);
		List<LoanMaster> loans = query.getResultList();
		for (LoanMaster loanMasterTemp : loans) {
			if (loanMasterTemp.getLoanAccountNumber() == loanAccNum) {
				loanMaster = loanMasterTemp;
			}
		}
		return loanMaster;
	}

	public LoanMaster updateEmiDao(LoanMaster loanMaster) {
		LOGGER.info("EMI is being updated in database.");
		loanMaster.setNumOfEmisPaid(loanMaster.getNumOfEmisPaid() + 1);
		loanMaster.setNextEmiDate(loanMaster.getNextEmiDate().plusMonths(1));
		return entityManager.merge(loanMaster);
	}

	public LoanMaster updateBalanceDao(LoanMaster loanMaster, BigDecimal balance) {
		LOGGER.info("Balance is being updated in database.");
		loanMaster.setBalance(balance);
		return entityManager.merge(loanMaster);
	}

	public void updatePreClosureDao(LoanMaster loanMaster) {
		LOGGER.info("PreClosure is being updated in database.");
		loanMaster.setLoanStatus(LoanStatus.PRE_CLOSURE_VERIFICATION);
		entityManager.merge(loanMaster);
	}

	public List<LoanMaster> getPendingLoans() {
		LOGGER.info("Pending loans are being fetched from database.");
		TypedQuery<LoanMaster> query = entityManager
				.createQuery("Select l.application_num from Loan l where l.loan_status = 'pending' ", LoanMaster.class);
		List<LoanMaster> pendingLoans = query.getResultList();

		Comparator<LoanMaster> loanApplicantNumComparator = new Comparator<LoanMaster>() {

			public int compare(LoanMaster o1, LoanMaster o2) {
				return o1.getApplicationNumber().compareTo(o2.getApplicationNumber());
			}
		};

		Collections.sort(pendingLoans, loanApplicantNumComparator);
		return pendingLoans;
	}

	public LoanMaster updateLoanApprovalDao(LoanMaster loanMasterTemp, BigInteger loanNumber) {
		loanMasterTemp.setLoanStatus(LoanStatus.APPROVED);
		loanMasterTemp.setLoanAccountNumber(loanNumber);
		return entityManager.merge(loanMasterTemp);

	}

	public void updateLoanDenialDao(LoanMaster loanMasterTemp) {
		loanMasterTemp.setLoanStatus(LoanStatus.DENIED);
		entityManager.merge(loanMasterTemp);
	}

}
