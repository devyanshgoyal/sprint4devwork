package com.cg.ibs.loanmgmt.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;

public interface BankService {
	public List<LoanMaster> getPendingLoans();

	public CustomerBean getCustomerDetailsByUci(BigInteger uci);

	public LoanTypeBean getLoanTypeByTypeID(Integer typeId);

	public BigInteger generateLoanNumber(LoanMaster loanMaster);

	public LoanMaster updateLoanApproval(LoanMaster loanMasterTemp);

	public void updateLoanDenial(LoanMaster loanMasterTemp);
}
