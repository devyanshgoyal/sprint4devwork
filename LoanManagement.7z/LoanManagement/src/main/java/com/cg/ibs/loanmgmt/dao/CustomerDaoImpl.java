package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class CustomerDaoImpl implements CustomerDao {
	private static EntityManager entityManager;
	private CustomerBean customerBean = new CustomerBean();

	public CustomerDaoImpl() {
		entityManager = JpaUtil.getEntityManger();
	}

	public CustomerBean getCustomerDetailsByUci(BigInteger uci) {
		return entityManager.find(CustomerBean.class, uci);
	}
}
