package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;

public interface CustomerDao {

	public CustomerBean getCustomerDetailsByUci(BigInteger uci);

}
