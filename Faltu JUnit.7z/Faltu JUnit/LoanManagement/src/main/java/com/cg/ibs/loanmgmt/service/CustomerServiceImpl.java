package com.cg.ibs.loanmgmt.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanStatus;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDaoImpl;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDaoImpl;
import com.cg.ibs.loanmgmt.dao.LoanTypeDao;
import com.cg.ibs.loanmgmt.dao.LoanTypeDaoImpl;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class CustomerServiceImpl implements CustomerService {
	private static Logger LOGGER = Logger.getLogger(CustomerServiceImpl.class);
	LoanTypeDao loanTypeDao = new LoanTypeDaoImpl();
	CustomerDao customerDao = new CustomerDaoImpl();
	LoanMasterDao loanMasterDao = new LoanMasterDaoImpl();

	@Override
	public LoanTypeBean getLoanTypeByTypeId(Integer typeId) {
		LOGGER.info("Fetching loan type details");
		return loanTypeDao.getLoanTypeByTypeID(typeId);
	}

	@Override
	public boolean verifyLoanAmount(BigDecimal loanAmount, BigDecimal maximumLimit, BigDecimal minimumLimit) {
		LOGGER.info("Verifying loan amount");
		boolean verify = false;
		if (loanAmount.compareTo(maximumLimit) < 0 && loanAmount.compareTo(minimumLimit) > 0) {
			verify = true;
		}
		return verify;
	}

	@Override
	public boolean verifyLoanTenure(int tenure) {
		LOGGER.info("Verifying loan tenure");
		boolean verify = false;
		if (tenure > 0 && (tenure % 6 == 0)) {
			verify = true;
		}
		return verify;
	}

	@Override
	public LoanMaster calculateEmi(LoanMaster loanMaster) {
		LOGGER.info("Calculating EMI amount");
		Float rate = loanTypeDao.getLoanTypeByTypeID(loanMaster.getTypeId()).getInterestRate() / (12 * 100);
		Double onePlusRPoweredN = Math.pow((rate + 1), loanMaster.getLoanTenure());
		BigDecimal principal = loanMaster.getLoanAmount();
		BigDecimal emi = principal.multiply(BigDecimal.valueOf((rate * onePlusRPoweredN) / (onePlusRPoweredN - 1)));
		loanMaster.setEmiAmount(emi.setScale(2, BigDecimal.ROUND_UP));
		return loanMaster;
	}

	@Override
	public boolean verifyCustomerLogin(String userId, String password) {
		LOGGER.info("Verifying customer login details");
		boolean login = false;
		CustomerBean customer = customerDao.getCustomerByUserId(userId);
		if (null != customer && password.equals(customer.getPassword())) {
			login = true;
		}
		return login;
	}

	@Override
	public CustomerBean getCustomer(String userId) {
		LOGGER.info("Fetching customer details");
		return customerDao.getCustomerByUserId(userId);
	}

	@Override
	public LoanMaster applyLoan(CustomerBean customer, LoanMaster loanMaster, String path) {
		EntityTransaction transaction = JpaUtil.getTransaction();
		loanMaster.setUci(customer.getUci());
		loanMaster.setAppliedDate(LocalDate.now());
		loanMaster.setBalance(loanMaster.getLoanAmount());
		loanMaster.setStatus(LoanStatus.PENDING);
		loanMaster.setDocument(uploadDocument(path));
		transaction.begin();
		LoanMaster appliedLoan = loanMasterDao.applyLoan(loanMaster);
		transaction.commit();
		return appliedLoan;
	}

	private static byte[] uploadDocument(String path) {
		byte[] content = null;
		try (FileInputStream inStream = new FileInputStream(path)) {
			content = new byte[(int) inStream.available()];
			inStream.read(content);
		} catch (IOException exp) {
			exp.printStackTrace();
		}
		return content;
	}

}
