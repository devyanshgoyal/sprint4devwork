package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanStatus;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class LoanMasterDaoImpl implements LoanMasterDao {
	private static Logger LOGGER = Logger.getLogger(LoanMasterDaoImpl.class);
	private EntityManager entityManager;

	public LoanMasterDaoImpl() {
		entityManager = JpaUtil.getEntityManger();
	}

	@Override
	public LoanMaster applyLoan(LoanMaster loanMaster) {
		entityManager.persist(loanMaster);
		return loanMaster;
	}

	public LoanMaster updateLoanApprovalDao(LoanMaster loanMasterTemp, BigInteger loanNumber) {
		loanMasterTemp.setStatus(LoanStatus.APPROVED);
		loanMasterTemp.setLoanAccountNumber(loanNumber);
		return entityManager.merge(loanMasterTemp);

	}

	public void updateLoanDenialDao(LoanMaster loanMasterTemp) {
		loanMasterTemp.setStatus(LoanStatus.DENIED);
		entityManager.merge(loanMasterTemp);
	}

	public List<LoanMaster> getPendingLoans() {
		LOGGER.info("Pending loans are being fetched from database.");
		TypedQuery<LoanMaster> query = entityManager.createQuery("Select l from LoanMaster l where l.status ='PENDING'",
				LoanMaster.class);
		List<LoanMaster> pendingLoans = query.getResultList();

		Comparator<LoanMaster> loanApplicantNumComparator = new Comparator<LoanMaster>() {
		public int compare(LoanMaster o1, LoanMaster o2) {
				return o1.getApplicationNumber().compareTo(o2.getApplicationNumber());
			}
		};

		Collections.sort(pendingLoans, loanApplicantNumComparator);
		return pendingLoans;
	}

}
