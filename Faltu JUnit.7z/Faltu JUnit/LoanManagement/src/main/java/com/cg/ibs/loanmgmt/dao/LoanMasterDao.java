package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.loanmgmt.bean.LoanMaster;

public interface LoanMasterDao {
	LoanMaster applyLoan(LoanMaster loanMaster);
	
	public List<LoanMaster> getPendingLoans();
	
	public LoanMaster updateLoanApprovalDao(LoanMaster loanMasterTemp, BigInteger loanNumber);

	public void updateLoanDenialDao(LoanMaster loanMasterTemp);
}
