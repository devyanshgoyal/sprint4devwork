package com.cg.ibs.loanmgmt.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class CustomerDaoImpl implements CustomerDao {
	private static Logger LOGGER = Logger.getLogger(CustomerDaoImpl.class);
	private EntityManager entityManager;

	public CustomerDaoImpl() {
		entityManager = JpaUtil.getEntityManger();
	}
	
	public CustomerBean getCustomerDetailsByUci(BigInteger uci) {
		return entityManager.find(CustomerBean.class, uci);
	}

	@Override
	public CustomerBean getCustomerByUserId(String userId) {
		LOGGER.info("Fetching customer details");
		CustomerBean customer = new CustomerBean();
		TypedQuery<CustomerBean> query = entityManager.createQuery("select c from CustomerBean c where c.userId=?1",
				CustomerBean.class);
		query.setParameter(1, userId);
		customer = (CustomerBean) query.getSingleResult();
		return customer;
	}

}
